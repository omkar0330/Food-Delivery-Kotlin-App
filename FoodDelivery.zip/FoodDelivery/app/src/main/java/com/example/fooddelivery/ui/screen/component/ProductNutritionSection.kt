package com.example.fooddelivery.ui.screen.component

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.fooddelivery.data.Calories
import com.example.fooddelivery.data.NutritionState
import com.example.fooddelivery.data.ProductNutritionState
import com.example.fooddelivery.ui.theme.AppTheme

@Composable
fun ProductNutritionSection(
    modifier: Modifier = Modifier,
    state: ProductNutritionState
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ){
        SectionHeader(
            title = "Nutrition facts",
            calories = state.calories
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            state.nutrients.forEach { item ->
                NutritionItem(state = item)
            }
        }
    }
}

@Composable
fun SectionHeader(
    modifier: Modifier = Modifier,
    title: String,
    calories: Calories
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = AppTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = AppTheme.colors.onBackground
        )
        Text(
            text = "${calories.value} ${calories.unit}",
            style = AppTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = AppTheme.colors.onBackground
        )
    }
}


@Composable
private fun NutritionItem(
    modifier: Modifier = Modifier,
    state: NutritionState
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top: Amount + Unit in bold
        Text(
            text = "${state.amount} ${state.unit}",
            style = AppTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = AppTheme.colors.onBackground
        )

        // Bottom: Label with percentage (light text)
        Text(
            text = state.title,
            style = AppTheme.typography.bodySmall,
            fontWeight = FontWeight.Light,
            color = AppTheme.colors.onBackground.copy(alpha = 0.8f)
        )
    }
}
