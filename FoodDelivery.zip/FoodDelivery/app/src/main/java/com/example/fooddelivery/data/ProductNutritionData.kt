package com.example.fooddelivery.data

data class ProductNutritionState(
    val calories : Calories,
    val nutrients : List<NutritionState>
)


data class Calories(
    val value : String,
    val unit : String
)
data class NutritionState(
    val amount : String,
    val title : String,
    val unit : String
)

val ProductNutritionData = ProductNutritionState(
    calories = Calories(
        value = "650",
        unit = "Cal"
    ),
    nutrients = listOf(
        NutritionState(
            amount = "35",
            title = "Total Fat (45% DV)",
            unit = "g"
        ),
        NutritionState(
            amount = "43",
            title = "Total Carbs (16% DV)",
            unit = "g"
        ),
        NutritionState(
            amount = "36",
            title = "Protein",
            unit = "g"
        )
    )
)
