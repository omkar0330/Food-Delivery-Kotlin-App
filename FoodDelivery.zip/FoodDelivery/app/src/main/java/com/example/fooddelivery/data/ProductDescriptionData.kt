package com.example.fooddelivery.data

val ProductDescriptionData: String
    get() = "Build your perfect bite! Stack on tasty extras like cheddar cheese, " +
            "smoky bacon, and caramelized onion." +
            " We’ll show you the calories and nutrition, " +
            "so it’s flavor without surprises."