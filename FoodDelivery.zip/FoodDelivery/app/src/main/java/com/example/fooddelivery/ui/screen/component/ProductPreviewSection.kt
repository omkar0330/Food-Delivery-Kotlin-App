package com.example.fooddelivery.ui.screen.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import com.example.fooddelivery.R
import com.example.fooddelivery.data.ProductPreviewState
import com.example.fooddelivery.ui.theme.AppTheme

@Composable
fun ProductPreviewSection(
    modifier: Modifier = Modifier,
    state : ProductPreviewState = ProductPreviewState()
){
    Box(modifier = modifier.height(IntrinsicSize.Max)){
        ProductBackground(
            modifier=Modifier.padding(bottom = 24.dp)
        )
        Content(
            state = state,
            modifier = Modifier
                .statusBarsPadding()
                .padding(top = 24.dp)
        )
    }
}

@Composable
fun ProductBackground(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                color = AppTheme.colors.secondarySurface,
                shape = RoundedCornerShape(
                    bottomStart =  30.dp,
                    bottomEnd = 30.dp
                )
            )
    )
    
}
@Composable
private fun Content(
    modifier: Modifier = Modifier,
    state : ProductPreviewState = ProductPreviewState()
) {
    ConstraintLayout(
        modifier = modifier.fillMaxWidth()
    ) {
        val (actionBar, highlights, productImage) = createRefs()

        ActionBar(
            headline = "Mr.Cheesy",
            modifier = modifier
                .padding(horizontal = 18.dp)
                .constrainAs(actionBar) {
                    top.linkTo(parent.top)

                }

        )
        Image(
            painter = painterResource(id = R.drawable.burger30),
            contentDescription = null,
            contentScale = ContentScale.FillHeight,
            modifier = modifier
                .height(256.dp)
                .constrainAs(productImage) {
                    end.linkTo(parent.end)
                    top.linkTo(actionBar.bottom, margin = 20.dp)
                }

        )
        ProductHighlights(
            highlights = state.highlights,
            modifier = modifier.constrainAs(highlights) {
                start.linkTo(anchor = parent.start, margin = 20.dp)
                top.linkTo(productImage.top)

            }
        )

    }
}
    @Composable
    fun ActionBar(
        modifier: Modifier = Modifier,
        headline: String

    ) {
        Row(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = headline,
                style = AppTheme.typography.headline,
                color = AppTheme.colors.onSecondarySurface
            )
            CloseButton(modifier = Modifier)
        }
    }


@Composable
fun CloseButton(
        modifier: Modifier = Modifier
    ) {
        Surface(
            modifier = modifier.size(44.dp),
            shape = RoundedCornerShape(5.dp),
            color = AppTheme.colors.actionSurface,
            contentColor = AppTheme.colors.secondarySurface,
            shadowElevation = 5.dp,
        ) {
            Box(
                modifier = modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_close),
                    contentDescription = "Close Button",
                    modifier = modifier.size(24.dp)
                )

            }

        }
    }
