package com.example.fooddelivery.data

import androidx.annotation.DrawableRes
import com.example.fooddelivery.R

data class ProductFlavorState(
    val name: String,
    val price: String,
    @DrawableRes val imageRes: Int,

)
val ProductFlavorData = listOf(
    ProductFlavorState(
        imageRes = R.drawable.img_cheese30,
        name = "Cheddar",
        price = "$0.79"
    ),
    ProductFlavorState(
        imageRes = R.drawable.bacon_30,
        name = "Bacon",
        price = "$0.49"

    ),
    ProductFlavorState(
        imageRes = R.drawable.onion_30,
        name = "Onion",
        price = "$0.29"
    )
)