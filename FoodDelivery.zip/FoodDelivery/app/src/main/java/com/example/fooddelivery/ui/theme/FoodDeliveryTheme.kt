package com.example.fooddelivery.ui.theme

class FoodDeliveryTheme {

}
